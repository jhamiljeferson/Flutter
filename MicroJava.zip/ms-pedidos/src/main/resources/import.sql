INSERT INTO tb_pedido(data_hora, status) VALUES('2024-08-19', 'REALIZADO');
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(2, 'refrigerante', 1);

INSERT INTO tb_pedido(data_hora, status) VALUES('2024-08-20', 'REALIZADO');
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(2, 'água sem gás', 2);
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(1, 'pizza de calabresa', 2);
INSERT INTO tb_item_do_pedido(quantidade, descricao, pedido_id) VALUES(1, 'pizza de mussarela', 2);

