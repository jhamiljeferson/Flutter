package br.com.fiap.ms_pedidos.model;

public enum Status {
    CANCELADO,
    REALIZADO,
    PAGO,
    ENTREGUE,
    CONFIRMADO,
    PRONTO,
    NAO_AUTORIZADO
}
