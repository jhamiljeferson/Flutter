package com.example.exemplo_fluter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
