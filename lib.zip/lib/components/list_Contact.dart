import 'package:flutter/material.dart';

class Contact extends StatefulWidget {
  const Contact({super.key});

  @override
  State<Contact> createState() => _ContactState();
}

class _ContactState extends State<Contact> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: listaContatos.length,
      itemBuilder: (context, index) {
        Contato contato = listaContatos[index];
        return ListTile(
          leading: CircleAvatar(
            child: Text(contato.nome.substring(0, 1).toUpperCase()),
          ),
          title: Text(contato.nome),
          subtitle: Text(contato.email),
          trailing: IconButton(
            onPressed: () {
              
            },
            icon: const Icon(Icons.favorite_border,color: Colors.red,),
            
          ),
        );
      },
    );
  }
}

class Contato {
  String nome;
  String email;
  final String imageUrl;
  bool isFavorite;

  Contato({required this.nome, required this.email, required this.imageUrl, this.isFavorite = false });
}

List<Contato> listaContatos = [
  Contato(nome: "Johe Doe", email: "alice@example.com" ,imageUrl: 'https://via.placeholder.com/150'),
  Contato(nome: "Aline O. Austin", email: "bob@example.com", imageUrl: 'https://via.placeholder.com/150'),
  Contato(nome: "Douglas R. Broadway", email: "carol@example.com", imageUrl: 'https://via.placeholder.com/150'),
];













