import 'package:flutter/material.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lista de Contatos',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ContactListScreen(),
    );
  }
}

class ContactListScreen extends StatefulWidget {
  @override
  _ContactListScreenState createState() => _ContactListScreenState();
}

class _ContactListScreenState extends State<ContactListScreen> {
  

  int get favoriteCount =>
      contacts.where((contact) => contact.isFavorite).length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de Contatos'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16.0),
            child: Row(
              children: [
                Text('$favoriteCount favoritos'),
                const SizedBox(width: 16),
                IconButton(
                  icon: const Icon(Icons.favorite),
                  onPressed: () {
                  },
                ),
              ],
            ),
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(contacts[index].imageUrl),
            ),
            title: Text(contacts[index].name),
            subtitle: Text(contacts[index].email),
            trailing: IconButton(
              icon: Icon(
                contacts[index].isFavorite ? Icons.favorite : Icons.favorite_border,
                color: contacts[index].isFavorite ? Colors.red : null,
              ),
              onPressed: () {
                setState(() {
                  contacts[index].isFavorite = !contacts[index].isFavorite;
                });
              },
            ),
          );
        },
      ),
    );
  }
}


class Contact {
  final String name;
  final String email;
  final String imageUrl;
  bool isFavorite;

  Contact({required this.name, required this.email, required this.imageUrl, this.isFavorite = false});
} 
List<Contact> contacts = [
    Contact(name: 'Johe Doe', email: 'alice@example.com', imageUrl: 'https://via.placeholder.com/150'),
    Contact(name: 'Aline O', email: 'bob@example.com', imageUrl: 'https://via.placeholder.com/150'),
    Contact(name: 'Douglas R. Broadway', email: 'carol@example.com', imageUrl: 'https://via.placeholder.com/150'),
  ];