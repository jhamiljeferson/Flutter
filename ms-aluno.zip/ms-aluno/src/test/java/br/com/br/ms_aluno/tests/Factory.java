package br.com.br.ms_aluno.tests;

import br.com.br.ms_aluno.dto.AlunoDTO;
import br.com.br.ms_aluno.model.Aluno;
import br.com.br.ms_aluno.model.Status;

import java.math.BigDecimal;

public class Factory {
    public static Aluno createAluno(){

        Aluno aluno = new Aluno(1L,
                "Bach", "jefersonjhamil@gmail.com", "123456789","93659",
                Status.MSTRICULADO, "3SIPG");
        return aluno;
    }

    public static AlunoDTO createAlunoDTO(){
        Aluno aluno = createAluno();
        return new AlunoDTO(aluno);
    }

    public static AlunoDTO createNewAlunoDTO(){
        Aluno aluno = createAluno();
        aluno.setId(null);
        return new AlunoDTO(aluno);
    }
}
