package br.com.br.ms_aluno.repository;

import br.com.br.ms_aluno.model.Aluno;
import br.com.br.ms_aluno.tests.Factory;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Optional;

@DataJpaTest
public class AlunoRepositoryTests {

    @Autowired
    private AlunoRepository repository;

    private Long existingId;
    private Long nonExistingId;
    private Long countTotalAluno;

    //Vai ser executado antes de cada teste
    @BeforeEach
    void setup() throws Exception{
        existingId = 1L;
        nonExistingId = 100L;
        //verificar quanto registro tem no seed
        countTotalAluno = 3L;
    }

    @Test
    @DisplayName("Deveria excluir aluno quando Id existe")
    public void deleteShouldDeletObjectWhenIdExists() {
        // Act
        repository.deleteById(existingId);
        // Assert
        Optional<Aluno> result = repository.findById(existingId);
        //testa se existe um obj dentro do Optional
        Assertions.assertFalse(result.isPresent());
    }

    @Test
    @DisplayName("save Deveria salvar objeto com auto incremento quando Id é nulo")
    public void saveShouldPersistWithAutIncrementWhenIdIsNull(){

        Aluno aluno = Factory.createAluno();
        aluno.setId(null);
        aluno = repository.save(aluno);
        Assertions.assertNotNull(aluno.getId());
        // verifica se é o próximo ID
        Assertions.assertEquals(countTotalAluno + 1, aluno.getId());
    }

    @Test
    @DisplayName("findById Deveria retornar um Optional não vazio quando o Id existe")
    public void findByIdShoulReturnNonEmptyOptionalWhenExistsId(){

        Optional<Aluno> result = repository.findById(existingId);
        Assertions.assertTrue(result.isPresent());
    }

    @Test
    @DisplayName("findById Deveria retornar um Optional vazio quando o Id não existe")
    public void findByIdShoulReturnEmptyOptionalWhenIdDoesNotExists(){

        Optional<Aluno> result = repository.findById(nonExistingId);
        Assertions.assertFalse(result.isPresent());
        // ou
        Assertions.assertTrue(result.isEmpty());
    }
}








