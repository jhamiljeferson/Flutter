package br.com.br.ms_aluno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
