package br.com.br.ms_aluno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAlunoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAlunoApplication.class, args);
	}

}
