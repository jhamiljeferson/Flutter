package br.com.br.ms_aluno.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

@Entity
@Table(name = "tb_aluno")
public class Aluno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nome;

    @Column(unique = true)
    private String email;

    private String password;

    private String rm;

    @Column(nullable = false)
    @Enumerated(value = EnumType.STRING)
    private Status status;

    private String turma;

}
