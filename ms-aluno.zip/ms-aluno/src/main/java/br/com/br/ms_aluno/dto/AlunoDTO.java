package br.com.br.ms_aluno.dto;

import br.com.br.ms_aluno.model.Aluno;
import br.com.br.ms_aluno.model.Status;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AlunoDTO {

    private Long id;

    @NotBlank(message = "Campo requerido")
    @Size(min = 3, message = "O nome deve ter no mínimo 3 caracteres")
    private String nome;

    @Email(message = "E-mail inválido")
    @NotBlank(message = "Campo requerido")
    private String email;

    @NotBlank(message = "Campo requerido")
    @Size(min = 8, message = "A senha deve ter no mínimo 8 caracteres")
    private String password;

    @NotBlank(message = "Campo requerido")
    @Size(min = 5, message = "O RM deve ter no mínimo 5 caracteres")
    private String rm;

    @Enumerated(value = EnumType.STRING)
    private Status status;

    @NotBlank(message = "Campo requerido")
    private String turma;

    public AlunoDTO(Aluno entity){
        id = entity.getId();
        nome = entity.getNome();
        email = entity.getEmail();
        password = entity.getPassword();
        rm = entity.getRm();
        status = entity.getStatus();
        turma = entity.getTurma();
    }

}
