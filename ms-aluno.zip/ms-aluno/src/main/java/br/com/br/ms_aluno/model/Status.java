package br.com.br.ms_aluno.model;

public enum Status {
    MSTRICULADO,
    TRANCADO,
    FORMADO,
    CANCELADO,
}
