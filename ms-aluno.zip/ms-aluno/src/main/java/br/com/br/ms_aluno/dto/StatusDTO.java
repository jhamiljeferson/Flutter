package br.com.br.ms_aluno.dto;

import br.com.br.ms_aluno.model.Status;
import lombok.Getter;

@Getter
public class StatusDTO {
    private Status status;
}
