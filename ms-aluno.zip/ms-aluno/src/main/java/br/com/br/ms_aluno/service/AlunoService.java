package br.com.br.ms_aluno.service;

import br.com.br.ms_aluno.dto.AlunoDTO;
import br.com.br.ms_aluno.model.Aluno;
import br.com.br.ms_aluno.repository.AlunoRepository;
import br.com.br.ms_aluno.service.exception.DatabaseException;
import br.com.br.ms_aluno.service.exception.ResourceNotFoundException;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AlunoService {
    @Autowired
    private AlunoRepository repository;

    @Transactional(readOnly = true)
    public List<AlunoDTO> findAll(){
        return repository.findAll().stream()
                .map(AlunoDTO::new).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AlunoDTO findById(Long id){
        Aluno entity = repository.findById(id).orElseThrow(
        ()-> new ResourceNotFoundException("Recurso não encontrado! Id: "  + id)
        );
        return new AlunoDTO(entity);
    }

    @Transactional
    public AlunoDTO insert(AlunoDTO dto){
        Aluno entity = new Aluno();
        copyDtoToEntity(dto, entity);
        entity = repository.save(entity);
        return new AlunoDTO(entity);
    }

    @Transactional
    public AlunoDTO update(Long id, AlunoDTO dto){
        try{
            Aluno entity = repository.getReferenceById(id);
            copyDtoToEntity(dto, entity);
            entity = repository.save(entity);
            return new AlunoDTO(entity);
        }catch (EntityNotFoundException e){
            throw new ResourceNotFoundException("Recurso não encontrado! Id: " + id);
        }
    }
    @Transactional
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Recurso não encontrado! Id: " + id);
        }
        try {
            repository.deleteById(id);
        } catch (DataIntegrityViolationException e) {
            throw new DatabaseException("Falha de integridade referencial");
        }
    }
    private void copyDtoToEntity(AlunoDTO dto, Aluno entity){
        entity.setNome(dto.getNome());
        entity.setEmail(dto.getEmail());
        entity.setPassword(dto.getPassword());
        entity.setRm(dto.getRm());
        entity.setStatus(dto.getStatus());
        entity.setTurma(dto.getTurma());
    }

}
