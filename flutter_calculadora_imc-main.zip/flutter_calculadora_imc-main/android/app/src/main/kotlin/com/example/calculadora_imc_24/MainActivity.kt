package com.example.calculadora_imc_24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
